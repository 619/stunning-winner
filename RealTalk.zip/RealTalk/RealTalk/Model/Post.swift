//
//  Post.swift
//
//
//  Created by The Bobby Zhang on 10/10/2017.
//  Copyright © 2017 Bobby Zhang. All rights reserved.
//

import Foundation
import FirebaseAuth
class Post {
    var caption: String?
    var photoUrl: String?
    var senderid: String?
    var uid: String?
    var id: String?
        //var ratio: CGFloat?
    var timestamp: Int?
}

extension Post {
    static func transformPostPhoto(dict: [String: Any], key: String) -> Post {
        let post = Post()
        post.id = key
        post.caption = dict["caption"] as? String
        post.photoUrl = dict["photoUrl"] as? String
        post.uid = dict["uid"] as? String
        post.senderid = dict["senderid"] as? String
        //post.ratio = dict["ratio"] as? CGFloat
        post.timestamp = dict["timestamp"] as? Int
      
        return post
    }
}
