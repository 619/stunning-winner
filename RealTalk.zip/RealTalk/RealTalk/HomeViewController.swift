//
//  HomeViewController.swift
//  RealTalk
//
//  Created by Bobby Zhang on 2017-10-10.
//  Copyright © 2017 com. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    
    @IBOutlet weak var slider: UISegmentedControl!
    
    var user: UserModel!


    @IBOutlet weak var tableView: UITableView!
    var posts = [Post]()
    //    var postIdsIndex = [String: Int]()
    var users = [UserModel]()
    var selectedIndex: Int?
    var kPagination = 3
    let refreshControl = UIRefreshControl()
    
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    
    @IBAction func playButton_TouchUpInside(_ sender: Any) {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "PlayViewController")
        self.present(nextViewController, animated:true, completion:nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        //tableView.estimatedRowHeight = 521
        selectedIndex = slider.selectedSegmentIndex
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.dataSource = self
        tableView.delegate = self
        refreshControl.addTarget(self, action: #selector(self.refresh), for: UIControlEvents.valueChanged)
        tableView.refreshControl = refreshControl
        loadPosts()
        // Do any additional setup after loading the view.
    }

    @objc func refresh() {
        self.posts.removeAll()
        self.users.removeAll()
        self.kPagination = 3
        loadPosts()
    }
    func reset() {
        self.posts.removeAll()
        self.users.removeAll()
        self.kPagination = 3
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func sliderValueChanged(_ sender: Any) {
        selectedIndex = slider.selectedSegmentIndex
        refresh()
    }
    
    func loadPosts() {
        if (selectedIndex == 0) {
            //        Api.Feed.observeFeed(withId: Api.User.CURRENT_USER!.uid, kPagination: kPagination, loadMore: false, completion: { (post, user) in
            Api.Feed.observeFeed(withId: "TESTING", kPagination: kPagination, loadMore: false, completion: { (post, user) in
                self.posts.insert(post, at: 0)
                self.users.insert(user, at: 0)
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()
            }) { (bool) in
                
            }       // Api.Feed.observeFeedRemoved(withId: Api.User.CURRENT_USER!.uid) { (post) in
            Api.Feed.observeFeedRemoved(withId: "TESTING") { (post) in
                self.posts = self.posts.filter { $0.id != post.id }
                self.users = self.users.filter { $0.id! != post.uid }
                self.tableView.reloadData()
            }
        } else if selectedIndex == 1 {
            //        Api.Feed.observeFeed(withId: Api.User.CURRENT_USER!.uid, kPagination: kPagination, loadMore: false, completion: { (post, user) in
            Api.Feed.observeFriendFeed(withId: "bobby", kPagination: kPagination, loadMore: false, completion: { (post, user) in
                self.posts.insert(post, at: 0)
                self.users.insert(user, at: 0)
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()
            }) { (bool) in
                
            }       // Api.Feed.observeFeedRemoved(withId: Api.User.CURRENT_USER!.uid) { (post) in
            Api.Feed.observeFriendFeedRemoved(withId: "bobby") { (post) in
                self.posts = self.posts.filter { $0.id != post.id }
                self.users = self.users.filter { $0.id! != post.uid }
                self.tableView.reloadData()
            }
        } else {
            return
        }

    }
    
    func loadMore() {
        if selectedIndex == 0 {
            if kPagination <= posts.count {
                indicator.startAnimating()
                kPagination += 2
                let postCount = posts.count
                Api.Feed.observeFeed(withId: Api.User.CURRENT_USER!.uid, kPagination: kPagination, loadMore: true, postCount: postCount, completion: { (post, user) in
                    self.posts.append(post)
                    self.users.append(user)
                    self.tableView.reloadData()
                    self.indicator.stopAnimating()
                }, isHiddenIndicator: { (bool) in
                    if let bool = bool {
                        if bool == true {
                            self.indicator.stopAnimating()
                            
                        }
                    }
                })
            }
        } else if selectedIndex == 1 {
            if kPagination <= posts.count {
                indicator.startAnimating()
                kPagination += 2
                let postCount = posts.count
                Api.Feed.observeFriendFeed(withId: Api.User.CURRENT_USER!.uid, kPagination: kPagination, loadMore: true, postCount: postCount, completion: { (post, user) in
                    self.posts.append(post)
                    self.users.append(user)
                    self.tableView.reloadData()
                    self.indicator.stopAnimating()
                }, isHiddenIndicator: { (bool) in
                    if let bool = bool {
                        if bool == true {
                            self.indicator.stopAnimating()
                            
                        }
                    }
                })
            }
        } else {
            return
        }
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
     */

}


extension HomeViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PostCell", for: indexPath) as! HomeTableViewCell
        //if !posts.isEmpty && !users.isEmpty {
            let post = posts[indexPath.row]
            cell.post = post
      //  }
        return cell
    }
    
    func scrollViewWillBeginDecelerating(_ scrollView: UIScrollView) {
        loadMore()
    }
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        //  if let lastIndex = self.tableView.indexPathsForVisibleRows?.last {
        //      if lastIndex.row >= self.posts.count - 2 {
        //                print(kPagination)
        //                loadMore()
        //      }
        //  }
    }
    
}

//extension HomeViewController: HomeTableViewCellDelegate {
//
//    func goToCommentVC(postId: String) {
//        performSegue(withIdentifier: "CommentSegue", sender: postId)
//    }
//
//    func goToProfileUserVC(userId: String) {
//        performSegue(withIdentifier: "Home_ProfileSegue", sender: userId)
//    }
//
//    func goToHashTag(tag: String) {
//        performSegue(withIdentifier: "Home_HashTagSegue", sender: tag)
//    }
//}
//
